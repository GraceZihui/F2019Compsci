/*Grace Shang
 * Period 4
 */
package fracCalc;

public class Fraction {

	public Fraction() {
		// TODO Auto-generated constructor stub
	}

}
